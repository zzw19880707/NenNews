//
//  UINavigationController+PushAnimated.h
//  东北新闻网
//
//  Created by tenyea on 13-12-28.
//  Copyright (c) 2013年 佐筱猪. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UINavigationController (PushAnimated)

//从左到右
- (void)customLeftToRightPushViewController:(UIViewController *)viewController;
@end
