//
//  LocationViewController.m
//  东北新闻网
//
//  Created by tenyea on 13-12-21.
//  Copyright (c) 2013年 佐筱猪. All rights reserved.
//

#import "LocationViewController.h"
#import "Uifactory.h"

@interface LocationViewController ()

@end

@implementation LocationViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(AppDelegate *)appDelegate{
    AppDelegate *appDelegate=(AppDelegate *)[UIApplication sharedApplication].delegate;
    return  appDelegate;
}

-(void)setImg
{
    if ([user boolForKey:kisNightModel]) {
        [fi setImage:[UIImage imageNamed:@"btn_back.png"]];
        [fb addSubview:fi];
    }else{
        [fi setImage:[UIImage imageNamed:@"btn_backye.png"]];
        [fb addSubview:fi];
    }
}


- (void)viewDidLoad
{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(setImg) name:kNightModeChangeNofication object:nil];

    user = [NSUserDefaults standardUserDefaults];

    [super viewDidLoad];
//    self.navigationController.navigationBar.tintColor = NenNewsgroundColor;
	[self.view setBackgroundColor:NenNewsgroundColor];
    
    
    NSArray *viewControllers = self.navigationController.viewControllers;
    
    
    
    if (self.isCancelButton) {
        
        fb= [[LeftBarButton alloc]init];
        [fb addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
        
        //左边按钮
        UIBarButtonItem *leftBtn=[[UIBarButtonItem alloc]initWithCustomView:fb];
        self.navigationItem.leftBarButtonItem=[leftBtn autorelease];
        
    }else{
        if (viewControllers.count > 1 ) {
            
            fb= [[LeftBarButton alloc]init];
            [fb addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
            
            //左边按钮
            UIBarButtonItem *leftBtn=[[UIBarButtonItem alloc]initWithCustomView:fb];
            self.navigationItem.leftBarButtonItem=[leftBtn autorelease];
        }
    }
}

#pragma mark ----按钮事件
-(void)cencel{
    [self dismissViewControllerAnimated:YES completion:NULL];
}
-(void)backAction{
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)setTitle:(NSString *)title{
    [super setTitle:title];
    UILabel *titlelabel=[[UILabel alloc]initWithFrame:CGRectZero];
    titlelabel.font=[UIFont boldSystemFontOfSize:18.0f];
    titlelabel.backgroundColor= NenNewsgroundColor;
    titlelabel.text=title;
    titlelabel.textColor=NenNewsTextColor;
    [titlelabel sizeToFit];
    self.navigationItem.titleView = [titlelabel autorelease];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
