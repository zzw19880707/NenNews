//
//  RootViewController.h
//  东北新闻网
//
//  Created by tenyea on 13-12-19.
//  Copyright (c) 2013年 佐筱猪. All rights reserved.
//

#import "BaseViewController.h"
#import "BaseScrollView.h"
#import "ColumnTabelViewController.h"
#import "VedioNightModelView.h"
#import "BtnArray.h"
@interface RootViewController : BaseViewController <UIScrollViewEventDelegate,UIScrollViewDelegate,ColumnChangedDelegate,UItableviewEventDelegate,NewsNigthTabelViewDelegate,VedioNightModelViewDelegate>{
    BaseScrollView *_sc;
    UILabel *rl;
    int lastBtn;
}
-(void)columnChanged;

@property (nonatomic ,assign) BOOL isLoading;
@end
