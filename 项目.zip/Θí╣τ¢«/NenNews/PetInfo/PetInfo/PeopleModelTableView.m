//
//  PeopleModelTableView.m
//  东北新闻网
//
//  Created by apple on 14-9-4.
//  Copyright (c) 2014年 naxingbo. All rights reserved.
//

#import "PeopleModelTableView.h"
#import "ThemeManager.h"
#import "NightAndLoadingCell.h"
#import "Uifactory.h"
#import "UIImageView+WebCache.h"
#import "ColumnModel.h"
#define column_heigh 205.0f
#define titleLabel_font 17
#define timeLabel_font 13

@implementation PeopleModelTableView

-(id)init{
    self = [super init];
    if(self){
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(NightModeChangeNotification:) name:kNightModeChangeNofication object:nil];
        self.isMore = NO;
        self.HidenMore = YES;
        self.refreshHeader = YES;
        [self setBackgroundColor];
    }
    return self;
}
-(id)initwithData:(NSArray *)data{
    self = [self init];
    if (self) {
        self.data = data;
    }
    return self;
}
-(void)setBackgroundColor{
    self.backgroundColor = [[ThemeManager shareInstance]getBackgroundColor];
}

//- (void)b1Clicked
//{
//    [listdate removeAllObjects];
//    type=@"";
//    indexPage=1;
//    pageSize=10;
//    [self getActivity];
//    [dLine setFrame:CGRectMake(0, 43, 108, 2)];
//    [dLine setBackgroundColor:[UIColor colorWithRed:112./255 green:181./255 blue:1 alpha:1]];
//    [btv addSubview:dLine];
//    [b1 setTitleColor:[UIColor colorWithRed:112./255 green:181./255 blue:1 alpha:1] forState:UIControlStateNormal];
//    [b2 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
//    [b3 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
//}
//
//- (void)b2Clicked
//{
//    [listdate removeAllObjects];
//    type=@"shetuan";
//    indexPage=1;
//    pageSize=10;
//    [self getActivity];
//    [dLine setFrame:CGRectMake(106, 43, 108, 2)];
//    [dLine setBackgroundColor:[UIColor colorWithRed:112./255 green:181./255 blue:1 alpha:1]];
//    [btv addSubview:dLine];
//    [b2 setTitleColor:[UIColor colorWithRed:112./255 green:181./255 blue:1 alpha:1] forState:UIControlStateNormal];
//    [b1 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
//    [b3 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
//}


#pragma mark - NSNotification actions
- (void)NightModeChangeNotification:(NSNotification *)notification {
    //标题颜色，选中后标题颜色变为选中颜色，未选中为标题颜色
    [self setBackgroundColor];
}


#pragma mark ----datasource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.data.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *listIndentifier=@"listIndentifier";
    UITableViewCell *cell  = [tableView dequeueReusableCellWithIdentifier:listIndentifier];
        if (cell==nil) {
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:listIndentifier];
            UILabel *label = [Uifactory createLabel:kmsText];
            label.tag = 10001;
            [label setFont:[UIFont fontWithName:@"Helvetica-Bold" size:titleLabel_font]];
            label.frame = CGRectMake(10, 10, cell.contentView.width-10, 30);
            [cell.contentView addSubview:label];
            
            UILabel *labelt = [Uifactory createLabel:kmstText];
            labelt.tag = 10002;
            labelt.font = [UIFont systemFontOfSize:timeLabel_font];
            labelt.frame = CGRectMake(10, 40, cell.contentView.width-10, 30);
            [cell.contentView addSubview:labelt];

        }
        UILabel *label = (UILabel *)VIEWWITHTAG(cell.contentView, 10001);
        NSDictionary *dic=[self.data objectAtIndex:indexPath.row];
        label.text= [dic objectForKey:@"complainTitle"];
    
        UILabel *labelt = (UILabel *)VIEWWITHTAG(cell.contentView, 10002);
        labelt.text= [NSString stringWithFormat:@"%@ %@",[dic objectForKey:@"updateTime"],[dic objectForKey:@"userAddress"]];
    
        if (WXHLOSVersion()>=7.0) {
            cell.backgroundColor = [[ThemeManager shareInstance ]getBackgroundColor];
        }else{
            cell.contentView.backgroundColor = [[ThemeManager shareInstance ]getBackgroundColor];
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
        return 80;
}


//卡住的头
-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    if (!btv) {
        btv=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 45)];
        b1=[[UIButton alloc]initWithFrame:CGRectMake(2, 0, 160, 45)];
        b2=[[UIButton alloc]initWithFrame:CGRectMake(160, 0, 160, 45)];
        dLine=[[UILabel alloc]initWithFrame:CGRectMake(0, 43, 160, 2)];
        
        [b1 setTitle:@"校内活动" forState:UIControlStateNormal];
        b1.titleLabel.font=[UIFont fontWithName:@"Helvetica-Bold" size:14];
        [b1 setTitleColor:[UIColor colorWithRed:112./255 green:181./255 blue:1 alpha:1] forState:UIControlStateNormal];
        [b1 addTarget:self action:@selector(b1Clicked) forControlEvents:UIControlEventTouchUpInside];
        
        [b2 setTitle:@"社团活动" forState:UIControlStateNormal];
        b2.titleLabel.font=[UIFont fontWithName:@"Helvetica-Bold" size:14];
        [b2 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [b2 addTarget:self action:@selector(b2Clicked) forControlEvents:UIControlEventTouchUpInside];
        
        [btv setBackgroundColor:[UIColor whiteColor]];
        
        [dLine setBackgroundColor:[UIColor colorWithRed:112./255 green:181./255 blue:1 alpha:1]];
        
        [btv addSubview:b1];
        [btv addSubview:b2];
        [btv addSubview:dLine];
    }
    
    return btv;
}


@end