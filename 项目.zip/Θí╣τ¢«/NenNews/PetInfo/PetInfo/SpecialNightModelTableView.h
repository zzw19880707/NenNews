//
//  SpecialNightModelTableView.h
//  东北新闻网
//
//  Created by tenyea on 14-1-26.
//  Copyright (c) 2014年 佐筱猪. All rights reserved.
//

#import "BaseTableView.h"
@interface SpecialNightModelTableView : BaseTableView

@property (nonatomic,retain) NSDictionary *ImgData;
@property (nonatomic,retain) NSString *abstract;

@end
