//
//  UIView+Additions.h
//  testLanucher
//
//  Created by 佐筱猪 on 13-10-31.
//  Copyright (c) 2013年 佐筱猪. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Additions)
-(UIViewController *)viewController;
@end
