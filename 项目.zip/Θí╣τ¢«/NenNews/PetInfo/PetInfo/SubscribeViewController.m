//
//  SubscribeViewController.m
//  东北新闻网
//
//  Created by tenyea on 14-2-8.
//  Copyright (c) 2014年 佐筱猪. All rights reserved.
//

#import "SubscribeViewController.h"
#import "Uifactory.h"
#import "VedioAndImageModel.h"
#import "PlayerViewController.h"
#import "ColumnTabelViewController.h"
#import "ACNavBarDrawer.h"

@interface SubscribeViewController ()<ACNavBarDrawerDelegate>
{
    VedioAndImageModel *_model ;
    BOOL _enable;
    
    /** 导航栏 按钮 加号 图片 */
    UIImageView *_plusIV;
    
    /** 是否已打开抽屉 */
    BOOL _isOpen;
    
    /** 抽屉视图 */
    ACNavBarDrawer *_drawerView;

}

@end

@implementation SubscribeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
//        self.title = @"订阅";
        UILabel *tLabel=[Uifactory createLabel:ttitleText];
        tLabel.frame=CGRectMake(0, 0, 100, 30);
        tLabel.font=[UIFont fontWithName:@"Helvetica-Bold" size:20.0];
        tLabel.textAlignment=UITextAlignmentCenter;
        tLabel.text=@"订阅";
        self.navigationItem.titleView=tLabel;

    }
    return self;
}

-(void)initRightBtn{
    
    UIButton *rb=[[UIButton alloc]initWithFrame:CGRectMake(0, 0, 80, 30)];
    
    [rb addTarget:self action:@selector(navPlusBtnPressed:) forControlEvents:UIControlEventTouchUpInside];
    UIImageView *ri=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"btn_arrowdown.png"]];
    if (IOS7_OR_LATER) {
        [ri setFrame:CGRectMake(80, 10, 10, 10)];
        rl=[Uifactory createLabel:ktext];
        [rl setFrame:CGRectMake(0, 0, 75, 30)];
    }else{
        [ri setFrame:CGRectMake(70, 10, 10, 10)];
        rl=[Uifactory createLabel:ktext];
        [rl setFrame:CGRectMake(-10, 0, 75, 30)];
    }
    rl.textAlignment=NSTextAlignmentRight;
    rl.text=@"今日网谈";
    [rl setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
    
    [rb addSubview:rl];
    [rb addSubview:ri];
    //右边按钮
    UIBarButtonItem *rightBtn=[[UIBarButtonItem alloc]initWithCustomView:rb];
    self.navigationItem.rightBarButtonItem=rightBtn;
    
    //*********************************************************************************************;
    
    
    //** 抽屉 *******************************************************************************
    
    //-- 按钮信息 -------------------------------------------------------------------------------
    // 就不建数据对象了，第一个为图片名、第二个为按钮名
    //    NSMutableArray *item_01 = [NSMutableArray arrayWithObjects:@"kinds_new", @"最新", nil];
    //    NSMutableArray *item_02 = [NSMutableArray arrayWithObjects:@"kinds_hot", @"最热", nil];
    //    NSMutableArray *item_03 = [NSMutableArray arrayWithObjects:@"kinds_more", @"分类", nil];
    //    NSMutableArray *item_04 = [NSMutableArray arrayWithObjects:@"kinds_create", @"发布", nil];
    
    // 最好是 2-5 个按钮，1个很2，5个以上很丑
    //    NSMutableArray *allItems = [NSMutableArray arrayWithObjects:item_01,item_02,item_03, item_04,item_01,item_01,item_01,item_01, nil];
    NSMutableArray *allItems = [[NSMutableArray alloc]init];
    
    //栏目数组
    NSMutableArray *nameArrays = [[NSMutableArray alloc]initWithArray:[[NSUserDefaults standardUserDefaults] objectForKey:subscribe_column]];
    for (int i =0; i<nameArrays.count; i++) {
        NSMutableArray *item = [NSMutableArray arrayWithObjects:@"", [NSString stringWithFormat:@"%@",[nameArrays[i] objectForKey:@"name"]], nil];
        [allItems addObject:item];
    }
    _drawerView = [[ACNavBarDrawer alloc] initWithView:self.view andItemInfoArray:allItems];
    _drawerView.delegate = self;
    
    lastBtn=1000;
    [user setValue:[NSString stringWithFormat:@"%i",lastBtn] forKey:@"lastBtn"];
    
    NSMutableArray *btnsArray = [[NSMutableArray alloc]init];
    BtnArray *btnArray=[BtnArray GetInstace];
    btnsArray=[btnArray getBtns];
    for (UIView *v1 in btnsArray) {
        NSArray *array1=[v1 subviews];
        for (UIView *v2 in array1) {
            if (v2.tag==lastBtn) {
                v2.hidden=NO;
            }
        }
    }
    
}
- (void)navPlusBtnPressed:(UIButton *)sender
{
    // 如果是关，则开，反之亦然
    if (_drawerView.isOpen == NO)
    {
        //        self.table.scrollEnabled=NO;
        [_drawerView openNavBarDrawer];
    }
    else
    {
        //        self.table.scrollEnabled=YES;
        [_drawerView closeNavBarDrawer];
    }
    
    //    [self rotatePlusIV];
}

- (void)viewWillDisappear:(BOOL)animated
{
    //    self.table.scrollEnabled=YES;
    // 消失时 关闭抽屉
    _isOpen = NO;
    [_drawerView closeNavBarDrawer];
    
    
    [super viewWillDisappear:animated];
    //    禁用左滑、右滑菜单
    [self.appDelegate.menuCtrl setEnableGesture:NO];
    
}

#pragma mark - ACNavBarDrawerDelegate

-(void)theBtnPressed:(UIButton *)theBtn
{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"culomanssdf" object:theBtn userInfo:nil];
    
    NSMutableArray *btnsArray = [[NSMutableArray alloc]init];
    BtnArray *btnArray=[BtnArray GetInstace];
    btnsArray=[btnArray getBtns];
    for (UIView *v1 in btnsArray) {
        NSArray *array1=[v1 subviews];
        for (UIView *v2 in array1) {
            if (v2.tag==lastBtn) {
                v2.hidden=YES;
            }
        }
    }
    
    NSMutableArray *nameArrays = [[NSMutableArray alloc]initWithArray:[[NSUserDefaults standardUserDefaults] objectForKey:subscribe_column]];
    rl.text=[nameArrays[theBtn.tag-1000] objectForKey:@"name"];
    NSArray *array=[theBtn subviews];
    for (UIView *v in array) {
        if (v.tag==theBtn.tag) {
            v.hidden=NO;
        }
    }
    lastBtn=theBtn.tag;
    
}

-(void)theBGMaskTapped
{
    //    self.table.scrollEnabled=YES;
    // 触摸背景遮罩时，需要通过回调，旋回加号图片
}




//初始化按钮
-(NSArray *)_initButton {
    
    //栏目数组
    NSMutableArray *nameArrays = [[NSMutableArray alloc]initWithArray:[[NSUserDefaults standardUserDefaults] objectForKey:subscribe_column]];
    //    用于存放按钮
    NSMutableArray *buttonArrays = [[NSMutableArray alloc]init];
    
    //    用于存放tableview
    NSMutableArray *tableArrays = [[NSMutableArray alloc]init];
    for (int i =0; i<nameArrays.count; i++) {
        int columnId = [[nameArrays[i] objectForKey:@"columnId"] intValue];
        UIButton *button = [Uifactory createButton:[nameArrays[i] objectForKey:@"name"]];
        button.frame = CGRectMake(10 + 70*i, 0, 60, 30);
        button.titleLabel.font = [UIFont systemFontOfSize:10];
        button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
        button.tag = 1000+ i;
        [buttonArrays addObject:button];
        
        VedioNightModelView *vedio = [[VedioNightModelView alloc]init];
        vedio.tag = 1300 +i;
        vedio.eventDelegate = self;
        vedio.frame = CGRectMake(340 *i, 0, ScreenWidth, ScreenHeight -44-20);
        vedio.columnID = columnId;
        vedio.VedioDelegate = self;
        vedio.type = 3;//视频
        vedio.separatorStyle = UITableViewCellSeparatorStyleNone;
        [self getData:vedio cache:1];
        [tableArrays addObject:vedio];
        [vedio release];
        
    }
    //    用于存放按钮和tableview
    NSArray *arrays = @[buttonArrays,tableArrays];
    return arrays;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeIndex1) name:@"changeIndex" object:nil];

//    初始化界面
    [self _initButton];
    self.isLoading = NO;
    _sc = [[BaseScrollView alloc]initwithButtons:[self _initButton] WithFrame:CGRectMake(0, 0, 320, ScreenHeight)];
    _sc.eventDelegate = self;
    [self.view addSubview:_sc];
    
    VedioNightModelView *table  = (VedioNightModelView *) VIEWWITHTAG( VIEWWITHTAG(_sc, 10001), 1300);
    [self getData:table cache:0];

    [self initRightBtn];

}

-(void)changeIndex1{
    NSArray *arr=[user objectForKey:subscribe_column];
    int page =[[user objectForKey:@"index"] intValue];
    NSString *rltitle =[[arr objectAtIndex:page] objectForKey:@"name"];
    rl.text=rltitle;
    
    
    //滑动移动位置
    NSMutableArray *btnsArray = [[NSMutableArray alloc]init];
    BtnArray *btnArray=[BtnArray GetInstace];
    btnsArray=[btnArray getBtns];
    
    for (int i =1000; i<(1000+btnsArray.count); i++) {
        NSMutableArray *btnsArray = [[NSMutableArray alloc]init];
        BtnArray *btnArray=[BtnArray GetInstace];
        btnsArray=[btnArray getBtns];
        if (i!=(page+1000)) {
            UIView *v=btnsArray[(i-1000)];
            NSArray *array=[v subviews];
            for (UIView *vv in array) {
                if (vv.tag==i) {
                    vv.hidden=YES;
                }
            }
        }else{
            UIView *v=btnsArray[(i-1000)];
            NSArray *array=[v subviews];
            for (UIView *vv in array) {
                if (vv.tag==i) {
                    vv.hidden=NO;
                }
            }
            lastBtn=i;
        }
    }
}


#pragma mark UItableviewEventDelegate
//cache 0:正常缓存 1代表只读本地
-(void)getData :(VedioNightModelView *)tableView cache:(int)cache{
    [self getConnectionAlert];
    //    参数
    NSMutableDictionary *params  = [[NSMutableDictionary alloc]init];
    int count = [[NSUserDefaults standardUserDefaults]integerForKey:kpageCount];
    NSNumber *number = [NSNumber numberWithInt:((count+1)*10)];
    [params setValue:number forKey:@"count"];
    int columnID=tableView.columnID;
    [params setValue:[NSNumber numberWithInt:columnID] forKey:@"takePartId"];
    //    正常访问网络
    if (cache ==0) {
        [DataService requestWithURL:URL_getsubscribe_List andparams:params andhttpMethod:@"GET" completeBlock:^(id result) {
            tableView.lastDate = [NSDate date];
            tableView.isMore = true;
            NSArray *array =  [result objectForKey:@"videos"];
            if (array.count ==0) {
                [tableView doneLoadingTableViewData];
                return ;
            }
            NSMutableArray *listData = [[NSMutableArray alloc]init];
            
            for (NSDictionary *dic  in array) {
                VedioAndImageModel * model = [[VedioAndImageModel alloc]initWithDataDic:dic];
                [listData addObject:model];
                [model release];
            }
            tableView.data =listData;
            [tableView reloadData];

            [tableView doneLoadingTableViewData];
            
        } andErrorBlock:^(NSError *error) {
            [tableView doneLoadingTableViewData];
        }];
    }else{
        //        只读本地
        [DataService nocacheWithURL:URL_getsubscribe_List andparams:params completeBlock:^(id result) {
            tableView.isMore = true;
            NSArray *array =  [result objectForKey:@"videos"];
            if (array.count ==0) {
                [tableView doneLoadingTableViewData];
                return ;
            }
            NSMutableArray *listData = [[NSMutableArray alloc]init];
            for (NSDictionary *dic  in array) {
                VedioAndImageModel * model = [[VedioAndImageModel alloc]initWithDataDic:dic];
                [listData addObject:model];
                [model release];
            }
            tableView.data =listData;
            [tableView doneLoadingTableViewData];
            [tableView reloadData];
            
        } andErrorBlock:^(NSError *error) {
            [tableView doneLoadingTableViewData];
        }];
    }

}

//上拉刷新
-(void)pullDown:(VedioNightModelView *)tableView{
    if (![self getConnectionAlert]) {
        [tableView doneLoadingTableViewData];
        return;
    }
    [self getData:tableView cache:0];
    
}

//下拉加载
-(void)pullUp:(NewsNightModelTableView *)tableView{
    if (_isLoading ) {
        return;
    }
    
    if (![self getConnectionAlert]) {
        [tableView doneLoadingTableViewData];
        return;
    }
    //    参数
    NSMutableDictionary *params  = [[NSMutableDictionary alloc]init];
    int count = [[NSUserDefaults standardUserDefaults]integerForKey:kpageCount];
    NSNumber *number = [NSNumber numberWithInt:((count+1)*10)];
    [params setValue:number forKey:@"count"];
    int columnID=tableView.columnID;
    [params setValue:[NSNumber numberWithInt:columnID] forKey:@"takePartId"];
    if (tableView.data.count>0) {
        VedioAndImageModel *model = [tableView.data lastObject];
        NSString *sinceID = model.newsId;
        [params setValue:sinceID forKey:@"sinceId"];
    }
    [self getConnectionAlert];
    self.isLoading = YES;

    [DataService requestWithURL:URL_getsubscribe_List andparams:params andhttpMethod:@"GET" completeBlock:^(id result) {
        NSArray *array =  [result objectForKey:@"videos"];
        NSMutableArray *listData = [[NSMutableArray alloc]init];
        
        for (NSDictionary *dic  in array) {
            VedioAndImageModel * model = [[VedioAndImageModel alloc]initWithDataDic:dic];
            [listData addObject:model];
        }
        
        [tableView doneLoadingTableViewData];
        NSMutableArray *arr = [NSMutableArray arrayWithArray:tableView.data];
        [arr addObjectsFromArray:listData];
        tableView.data  = arr;

        if (listData.count < (count+1)*10) {
            tableView.isMore = false;
        }
        [tableView reloadData];
        self.isLoading = NO;

    } andErrorBlock:^(NSError *error) {
        [tableView doneLoadingTableViewData];
        self.isLoading = NO;

    }];
    
    
    
}

-(void)tableView:(VedioNightModelView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    [tableView deselectRowAtIndexPath:indexPath animated:YES];

}
#pragma mark VedioNightModelViewDelegate
-(void)selectedAction:(VedioAndImageModel *)model{
    if (model.videoUrl) {
        NSString *ktype =[DataCenter getConnectionAvailable];
        _model = model;
        if ([ktype isEqualToString:@"none"]) {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示"
                                                            message:INFO_NetNoReachable
                                                           delegate:nil
                                                  cancelButtonTitle:@"确定"
                                                  otherButtonTitles:nil];
            [alert show];
        }else if([ktype isEqualToString:@"wifi"]){
            
            [self play];
        }else{
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:INFO_Net3GReachable delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"继续", nil];
            [alert show];
            [alert release];
        }
    }
    

}
-(void)play {
    NSURL *url = [NSURL URLWithString:_model.videoUrl];
    PlayerViewController *playerViewController = [[PlayerViewController alloc] initWithContentURL:url];
    playerViewController.moviePlayer.shouldAutoplay=YES;
    [self.appDelegate.menuCtrl presentMoviePlayerViewControllerAnimated:playerViewController];
}
#pragma mark UIAlertViewDelegate
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 0 ) {
        
    }else{
        [self play];
    }
}

-(void)addButtonAction{
    ColumnTabelViewController *columnVC = [[ColumnTabelViewController alloc]initWithType:1];
    columnVC.eventDelegate = self;
    _po(self.navigationController);
    [self.navigationController pushViewController:columnVC animated:YES];
}
-(void)showRightMenu{
    [self.appDelegate.menuCtrl showRightController:YES];
    
}
-(void)showLeftMenu{
    [self.appDelegate.menuCtrl showLeftController:YES];
    
}
-(void)setEnableGesture:(BOOL)b{
    _enable = b;
    [self.appDelegate.menuCtrl setEnableGesture:b];
}
-(void)autoRefreshData:(VedioNightModelView *)tableView{
    [self getData:tableView cache:0];
}
//-(void)autoRefreshDatawithCache:(VedioNightModelView *)tableView{
//    [self getData:tableView cache:1];
//}
#pragma mark columnchangeDelegate
-(void)columnChanged:(NSArray *)array{
    _sc.buttonsNameArray = [self _initButton];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
