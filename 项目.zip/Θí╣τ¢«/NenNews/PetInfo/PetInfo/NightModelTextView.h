//
//  NightModelTextView.h
//  东北新闻网
//
//  Created by tenyea on 14-1-11.
//  Copyright (c) 2014年 佐筱猪. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NightModelTextView : UITextView

@property (nonatomic,assign) bool isStrong;

@end
