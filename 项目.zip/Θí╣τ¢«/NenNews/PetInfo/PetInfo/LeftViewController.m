//
//  LeftViewController.m
//  东北新闻网
//
//  Created by 佐筱猪 on 13-12-18.
//  Copyright (c) 2013年 佐筱猪. All rights reserved.
//

#import "LeftViewController.h"
#import "RootViewController.h"
#import "PushNewsViewController.h"
#import "CollectionViewController.h"
#import "BaseNavViewController.h"
#import "SubscribeViewController.h"
#import "SettingViewController.h"
#import "SearchViewController.h"
#import "WeatherViewController.h"
#import "ThemeManager.h"

@interface LeftViewController ()

@end

@implementation LeftViewController

@synthesize imageArray = _imageArray;
@synthesize nameArray =_nameArray;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated{
    if (WXHLOSVersion()>=7.0) {
        [self setStatusBarStyle:UIStatusBarStyleLightContent];
        [self setStatusBarHidden:NO];
    }else{
        [[UIApplication sharedApplication] setStatusBarHidden:NO];
    }
}
-(void)viewWillDisappear:(BOOL)animated{
    if (WXHLOSVersion()>=7.0) {
        [self setStatusBarStyle:UIStatusBarStyleDefault];
        [self setStatusBarHidden:NO];
    }else{
        [[UIApplication sharedApplication] setStatusBarHidden:NO];
    }
}

-(void)getWeather {
    if ([[DataCenter getConnectionAvailable] isEqualToString:@"none"]) {
        
    }else{
        DataService *service = [[DataService alloc]init];
        service.eventDelegate = self;
        NSString *locationcityid = [[NSUserDefaults standardUserDefaults] objectForKey:kLocationCityCode];
        NSString *url = [Weather_simple_URL stringByAppendingString:[NSString stringWithFormat:@"%@%@",locationcityid,@".html"]];
        [service requestWithURL:url andparams:nil isJoint:NO andhttpMethod:@"GET"];
    }
}
-(void)requestFailed:(ASIHTTPRequest *)request{
    
}
-(void)requestFinished:(id)result{
    NSDictionary *dic = [result objectForKey:@"weatherinfo"];
    todayWeather=dic;
    NSString *weather = [todayWeather objectForKey:@"weather"];
    NSString *temp2 = [todayWeather objectForKey:@"temp2"];
    NSString *temp1 = [todayWeather objectForKey:@"temp1"];
    NSString *weatherStr = @"";
    if ( weather == nil ||temp1 == nil ||temp2 == nil) {
        weatherStr = @"请稍后";
    }else{
        weatherStr = [NSString stringWithFormat:@"%@%@~%@",[todayWeather objectForKey:@"weather"],[todayWeather objectForKey:@"temp2"],[todayWeather objectForKey:@"temp1"]];
    }
    self.nameArray = @[@[@"图片新闻",
                         @"推送资讯",
                         @"我的收藏",
                         @"订阅版块"],
                       @[weatherStr,
                         @"下载离线",
                         @"夜晚/白天"],
                       @[@"设置"]];

    [_tableView reloadData];
    NSIndexPath *indexPath=[NSIndexPath indexPathForRow:0 inSection:0];
    [_tableView selectRowAtIndexPath:indexPath animated:YES  scrollPosition:UITableViewScrollPositionBottom];
    //[self _initFrame];
    //当日天气
//    UILabel *weatherLabel =(UILabel *)VIEWWITHTAG(self.view, 1021);
//    weatherLabel.text = [NSString stringWithFormat:@"%@/%@",[dic objectForKey:@"temp2"],[dic objectForKey:@"temp1"]];
}



//初始化背景图
-(void)_initFrame{
 
    UIView *backview =[[UIView alloc]init];
    backview.backgroundColor = COLOR(17, 17, 17);
    backview.frame = CGRectMake( 0, 0, ScreenWidth, ScreenHeight);
    //backview.alpha = 0.2;
    [self.view addSubview:backview];
    [backview release];
    
    UIView *background = [[UIImageView alloc]init];
    background.frame = CGRectMake( 0, 0, ScreenWidth, 20);
    background.backgroundColor=[UIColor clearColor];
    background.tag =1010;
    [self.view addSubview:background];
    [background release];
    
    //搜索按钮
    UIButton *sBtn=[[UIButton alloc]initWithFrame: CGRectMake(0.0, 0, 250, 40)];
    [sBtn addTarget:self action:@selector(searchBarClicked) forControlEvents:UIControlEventTouchUpInside];
    
    
    _searchBar = [[UISearchBar alloc] initWithFrame: CGRectMake(0.0, 0, 250, 40)];
    _searchBar.placeholder=@"请输入搜索关键字";
    _searchBar.delegate = self;
    _searchBar.showsCancelButton = NO;
    
    [_searchBar addSubview:sBtn];
    
    float version = [[[ UIDevice currentDevice ] systemVersion ] floatValue ];
    
    if ([_searchBar respondsToSelector : @selector (barTintColor)]) {
        
        float  iosversion7_1 = 7.1 ;
        if (version >= iosversion7_1)
        {
            [[[[ _searchBar.subviews objectAtIndex : 0 ] subviews ] objectAtIndex : 0 ] removeFromSuperview ];
            [_searchBar setBackgroundColor :[ UIColor clearColor ]];
        }else
        {
            //iOS7.0
            [ _searchBar setBarTintColor :[ UIColor clearColor ]];
            [ _searchBar setBackgroundColor :[ UIColor clearColor ]];
        }
    }else{
        //iOS7.0 以下
        [[_searchBar.subviews objectAtIndex : 0 ] removeFromSuperview ];
        [_searchBar setBackgroundColor :[UIColor clearColor ]];
    }
    //_searchBar.keyboardType = UIKeyboardTypeDefault;
    
    //[background addSubview: _searchBar];
    
    
    
    _tableView = [[UITableView alloc]init];
    _tableView.frame = CGRectMake(0, 25, 250, ScreenHeight-25);
    _tableView.scrollEnabled=NO;
    _tableView.bounces = NO;
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.backgroundColor = CLEARCOLOR;
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    [self.view addSubview:_tableView];
    _tableView.tableHeaderView=_searchBar;
    
    [todayWeather objectForKey:@"temp2"];
    [todayWeather objectForKey:@"temp1"];
    
    NSString *weather = [todayWeather objectForKey:@"weather"];
    NSString *temp2 = [todayWeather objectForKey:@"temp2"];
    NSString *temp1 = [todayWeather objectForKey:@"temp1"];
    NSString *weatherStr = @"";
    if ( weather == nil ||temp1 == nil ||temp2 == nil) {
        weatherStr = @"请稍后";
    }else{
        weatherStr = [NSString stringWithFormat:@"%@%@~%@",[todayWeather objectForKey:@"weather"],[todayWeather objectForKey:@"temp2"],[todayWeather objectForKey:@"temp1"]];
    }
    
    self.nameArray = @[@[@"图片新闻",
                       @"推送资讯",
                       @"我的收藏",
                       @"订阅版块"],
                       @[ weatherStr,
                        @"下载离线",
                        @"夜晚/白天"],
                       @[@"设置"]];
    self.imageArray = @[@[@"ico_img",
                        @"ico_tui",
                        @"ico_heart",
                        @"ico_eye"],
                        @[@"ico_weather",
                          @"ico_dload",
                          @"ico_sun"],
                        @[@"ico_set"]];
    //    默认选中第一条
    NSIndexPath *indexPath=[NSIndexPath indexPathForRow:0 inSection:0];
    [_tableView selectRowAtIndexPath:indexPath animated:YES  scrollPosition:UITableViewScrollPositionBottom];
    
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    userdefaults = [NSUserDefaults standardUserDefaults];
    todayWeather=[[NSDictionary alloc]init];
    [self _initFrame];
    [NSTimer  scheduledTimerWithTimeInterval:60 target:self selector:@selector(getWeather) userInfo:nil repeats:YES];
}


- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    NSLog( @"%s,%d" , __FUNCTION__ , __LINE__ );
    [_searchBar resignFirstResponder];
}

-(void)searchBarClicked
{
    BaseViewController *baseView = nil ;
    baseView = [[[SearchViewController alloc]init]autorelease];
    
    BaseNavViewController *navViewController = [[BaseNavViewController alloc]initWithRootViewController:baseView];
    [self.appDelegate.menuCtrl setRootController:navViewController animated:YES];

}
#pragma mark UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return [_nameArray count];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return [[_nameArray objectAtIndex:section] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *leftcell = @"leftcell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:leftcell];
    if (cell == Nil) {
        cell = [[[NSBundle mainBundle]loadNibNamed:@"LeftCell" owner:self options:nil] lastObject];
    }
    UIImageView *imageVIew = (UIImageView *)[cell.contentView viewWithTag:200];
  
    [imageVIew setImage:[UIImage imageNamed:[_imageArray[indexPath.section]objectAtIndex:indexPath.row]]];
    [imageVIew setHighlightedImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@wht",[_imageArray[indexPath.section]objectAtIndex:indexPath.row]]]];
    
    UILabel *label = (UILabel *)[cell.contentView viewWithTag:210];
    label.text = [_nameArray[indexPath.section]objectAtIndex:indexPath.row];
    label.font = FONT(18);
    label.textColor = COLOR(179, 179, 179);
    label.highlightedTextColor=[UIColor whiteColor];
    //ios7适配
    if (WXHLOSVersion()>=7.0) {
        cell.backgroundColor = COLOR(28, 28, 28);
    }else{
        cell.contentView.backgroundColor = COLOR(28, 28, 28);
    }
    //设置选中时颜色
    cell.selectedBackgroundView = [[[UIView alloc] initWithFrame:cell.frame] autorelease];
    cell.selectedBackgroundView.backgroundColor = COLOR(199, 0, 19);
    
    //设置选中状态
//    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return  cell;
}
-(UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    UIView *tv=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 10)];
    tv.backgroundColor=COLOR(17, 17, 17);
    return tv;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 45;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 10;
}
#pragma mark uitabledelegate
//选中修改mainviewcontroller 显示内容
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{


    BaseViewController *baseView = nil ;
    if (indexPath.section==0) {
        if (indexPath.row==0) {
            baseView = [[RootViewController alloc]init];
        }else if( indexPath.row==1){
            baseView = [[PushNewsViewController alloc]init];
        }else if( indexPath.row==2){
            baseView = [[CollectionViewController alloc]init];
        }else{
            baseView = [[SubscribeViewController alloc]init];
        }
    }else if (indexPath.section==1) {
        if( indexPath.row==0){
            //天气
            baseView = [[WeatherViewController alloc]init];
        }else if( indexPath.row==1){
            //首页开始下载
            [[NSNotificationCenter defaultCenter] postNotificationName:kofflineBeginNofication object:nil];
          
            [self.appDelegate.menuCtrl showRootController:YES];
            return;
            NSLog(@"下载离线");
        }else{
            if ([userdefaults boolForKey:kisNightModel]) {
                [ThemeManager shareInstance].nigthModelName = @"night";
                [userdefaults setBool:NO forKey:kisNightModel];
                [userdefaults synchronize];
                [[NSNotificationCenter defaultCenter]postNotificationName:kNightModeChangeNofication object:nil];
            }else{
                [ThemeManager shareInstance].nigthModelName = @"day";
                [userdefaults setBool:YES forKey:kisNightModel];
                [userdefaults synchronize];
                [[NSNotificationCenter defaultCenter]postNotificationName:kNightModeChangeNofication object:nil];
            }
            [self.appDelegate.menuCtrl showRootController:YES];
            return;
            NSLog(@"夜晚");
        }
    }else if (indexPath.section==2) {
        if (indexPath.row==0) {
            baseView = [[SettingViewController alloc]init];
            
            //[self.appDelegate.menuCtrl presentModalViewController:[[[BaseNavViewController alloc]initWithRootViewController: baseView]autorelease] animated:YES];
            
            NSLog(@"设置");
        }
    }
    
    BaseNavViewController *navViewController = [[BaseNavViewController alloc]initWithRootViewController:baseView];
    [self.appDelegate.menuCtrl setRootController:navViewController animated:YES];
    [baseView release];
    
    
}

#pragma mark 内存管理
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)dealloc {
    [super dealloc];
}
- (void)viewDidUnload {

    [super viewDidUnload];
}

@end
