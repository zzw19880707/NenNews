//
//  BaseNightModelCell.h
//  东北新闻网
//
//  Created by tenyea on 14-1-26.
//  Copyright (c) 2014年 佐筱猪. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseNightModelCell : UITableViewCell
@end
