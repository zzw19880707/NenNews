//
//  BtnArray.m
//  东北新闻网
//
//  Created by apple on 14-8-29.
//  Copyright (c) 2014年 佐筱猪. All rights reserved.
//

#import "BtnArray.h"

@implementation BtnArray


static BtnArray *instace;

+(BtnArray *)GetInstace
{
    @synchronized(self) {
        if (instace == nil) {
            instace = [[self alloc] init];
        }
    }
    return instace;

}

-(void) setBtns:(NSMutableArray *)btns
{
    btnArrays=btns;
}

-(NSMutableArray *) getBtns
{
    return btnArrays;
}

@end


