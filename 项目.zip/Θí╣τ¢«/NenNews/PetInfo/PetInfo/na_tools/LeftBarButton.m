//
//  LeftBarView.m
//  东北新闻网
//
//  Created by apple on 14-9-1.
//  Copyright (c) 2014年 naxingbo. All rights reserved.
//

#import "LeftBarButton.h"

@implementation LeftBarButton

- (id)init
{
    [super initWithFrame:CGRectMake(0, 0, 80, 30)];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeImg) name:kNightModeChangeNofication object:nil];
    user=[NSUserDefaults standardUserDefaults];
    
  
    fi=[[UIImageView alloc]init];
    if ([user boolForKey:kisNightModel]) {
        [fi setImage:[UIImage imageNamed:@"btn_back.png"]];
    }else{
        [fi setImage:[UIImage imageNamed:@"btn_backye.png"]];
    }
    UILabel *fl=[Uifactory createLabel:ttitleText];
    [fi setFrame:CGRectMake(0, 5, 20, 20)];
    [fl setFrame:CGRectMake(20, 0, 75, 30)];
    
    fl.textAlignment=NSTextAlignmentLeft;
    fl.text=@"东北新闻网";
    [fl setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12.0]];
    
    [self addSubview:fi];
    [self addSubview:fl];
    return self;
}

-(void)changeImg
{
    if ([user boolForKey:kisNightModel]) {
        [fi setImage:[UIImage imageNamed:@"btn_back.png"]];
    }else{
        [fi setImage:[UIImage imageNamed:@"btn_backye.png"]];
    }
}



@end
