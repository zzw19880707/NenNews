//
//  LeftBarView.h
//  东北新闻网
//
//  Created by apple on 14-9-1.
//  Copyright (c) 2014年 naxingbo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Uifactory.h"

@interface LeftBarButton : UIButton
{
    NSUserDefaults *user;
    UIImageView *fi;
}

@end
