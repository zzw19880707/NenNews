//
//  BtnArray.h
//  东北新闻网
//
//  Created by apple on 14-8-29.
//  Copyright (c) 2014年 佐筱猪. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BtnArray : NSObject
{
    NSMutableArray *btnArrays;
}

+(BtnArray *)GetInstace;
-(void) setBtns:(NSMutableArray *)btns;
-(NSMutableArray *) getBtns;

@end
