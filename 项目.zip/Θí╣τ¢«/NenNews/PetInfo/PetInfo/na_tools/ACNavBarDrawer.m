//
//  ACNavBarDrawer.m
//  ACNavBarDrawer
//
//  Created by albert on 13-7-29.
//  Copyright (c) 2013年 albert. All rights reserved.
//

#import "ACNavBarDrawer.h"

#define ACNavBarDrawer_Height       50
#define ACNavBarDrawer_Duration     0.3f
#define ACNav 30

@interface ACNavBarDrawer ()
{
    /** 背景遮罩 */
    UIControl               *_mask;
}

@end


@implementation ACNavBarDrawer


#pragma mark - Action Method

- (void)itemBtnPressed:(UIButton *)itemBtn
{
    if (nil != _delegate && [_delegate respondsToSelector:@selector(theBtnPressed:)])
    {
        [self closeNavBarDrawer];
        [_delegate theBtnPressed:itemBtn];
    }
}

- (void)maskTapped
{
    if (nil != _delegate && [_delegate respondsToSelector:@selector(theBGMaskTapped)])
    {
        [self closeNavBarDrawer];
        [_delegate theBGMaskTapped];
    }
}


#pragma mark - Private Methods

- (void)createButtonsByNumber:(NSInteger)number andItemInfoArray:(NSArray *)array
{
//    // 每个格子的宽度
//    CGFloat barItem_w = (App_Frame_Width / number);
//    
//    // 每个格子的 中点
//    CGFloat barItem_center_y = (ACNavBarDrawer_Height / 2.f+5-ACNav);
    
    // button 宽高
    
    CGFloat btn_w = 75.f;
    CGFloat btn_h = 40.f;
    CGFloat w = 4.f;
    NSMutableArray *btnsArray=[[NSMutableArray alloc]init];
    for (int i=0; i<number; i++) {
        float x=0;
        float y=0;
        x=i%4*btn_w+i%4*w+w;
        y=i/4*btn_h+i/4*w+10;
        NSString *labelText = [((NSArray *)[array objectAtIndex:i]) objectAtIndex:1];
        UIButton *theBtn = [[UIButton alloc] init];
        [theBtn setFrame:CGRectMake(x , y, btn_w, btn_h)];
        [theBtn setTitle:labelText forState:UIControlStateNormal];
        [theBtn setTitleColor:[UIColor colorWithRed:119./255 green:119./255 blue:119./255 alpha:1] forState:UIControlStateNormal];
        theBtn.titleLabel.font=[UIFont fontWithName:@"Helvetica-Bold" size:14.0];
        theBtn.tag=1000+i;
        [theBtn addTarget:self action:@selector(itemBtnPressed:) forControlEvents:UIControlEventTouchUpInside];
        
        UILabel *theLabel = [[UILabel alloc] init];
        [theLabel setFrame:CGRectMake(3, 3, 71, 36)];
        theLabel.hidden=YES;
        theLabel.text=labelText;
        theLabel.textAlignment=UITextAlignmentCenter;
        theLabel.backgroundColor=[UIColor colorWithRed:204./255 green:0 blue:0 alpha:1];
        theLabel.textColor=[UIColor whiteColor];
        [theLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:14.0]];
        theLabel.layer.masksToBounds = YES;
        theLabel.layer.cornerRadius = 3;
        theLabel.tag=1000+i;
        
        [btnsArray addObject:theBtn];
        [theBtn addSubview:theLabel];
        [self addSubview:theBtn];
    }
    if (number<=4) {
        barHeight=5;
    }else{
        if ((number%4)!=0) {
            barHeight=(int)(10+btn_h)*((number/4));
        }else{
            barHeight=(int)(10+btn_h)*((number/4)-1);
        }
    }
    
//    float a=barHeight+ ACNavBarDrawer_Height/2.f;
    
    [self setFrame:CGRectMake(0.f,
                              -(barHeight+ACNavBarDrawer_Height),
                              App_Frame_Width,
                              barHeight+ACNavBarDrawer_Height)];
    [self setCenter:CGPointMake( (App_Frame_Width / 2), -(barHeight+ACNavBarDrawer_Height / 2.f) )];
    
    
    BtnArray *btnArray=[BtnArray GetInstace];
    [btnArray setBtns:btnsArray];
}

#pragma mark - Public Methods

- (id)initWithView:(UIView *)theView andItemInfoArray:(NSArray *)theArray
{
    self = [super init];
    if (self)
    {
        // Initialization code
        
        _isOpen = NO;
        
        //-- 遮罩 view -----------------------------------------------------------------------------
        _mask = [[UIControl alloc] initWithFrame:[theView bounds]];
        
        [_mask setBackgroundColor:[UIColor blackColor]];
        [_mask addTarget:self action:@selector(maskTapped) forControlEvents:UIControlEventTouchUpInside];
        [_mask setAlpha:0.0f];
        [theView addSubview:_mask];
        //-----------------------------------------------------------------------------------------;
        
        [self setFrame:CGRectMake(0.f,
                                  -(barHeight+ACNavBarDrawer_Height),
                                  App_Frame_Width,
                                  barHeight+ACNavBarDrawer_Height)];
        [self setCenter:CGPointMake( (App_Frame_Width / 2), -( barHeight+ACNavBarDrawer_Height / 2.f) )];
//        [self setBackgroundColor:COLOR(0, 0, 0)];
//        
//        [self setAlpha:0.5f];
     
        [self setBackgroundColor:[UIColor colorWithRed:0 green:0 blue:0 alpha:0.8]];
        
//        self.layer.shadowColor = COLOR(0, 0, 0).CGColor;
//        self.layer.shadowOffset = CGSizeMake(0.0f, 1.0f);
//        self.layer.shadowRadius = 0.5f;
//        self.layer.shadowOpacity = 0.8f;
//        self.layer.masksToBounds = NO;
        
        UIBezierPath *path = [UIBezierPath bezierPathWithRect:self.bounds];
        self.layer.shadowPath = path.CGPath;        
        
        [theView addSubview:self];
        
        //-- 创建按钮 -------------------------------------------------------------------------------
        [self createButtonsByNumber:[theArray count] andItemInfoArray:theArray];
        self.hidden=YES;
        
    }
    return self;
}

- (void)openNavBarDrawer
{
    _isOpen = YES;
    self.hidden=NO;
    [UIView animateWithDuration:ACNavBarDrawer_Duration animations:^{
        
        [_mask setAlpha:0.3f];
        self.frame=CGRectMake(0, -5, App_Frame_Width, barHeight+ACNavBarDrawer_Height);
//        if (IOS7_OR_LATER) {
//            [self setCenter:CGPointMake( (App_Frame_Width / 2), ( barHeight+ACNavBarDrawer_Height/ 2.f)-30 )];
//            self.frame=CGRectMake(0, 0, App_Frame_Width, barHeight+ACNavBarDrawer_Height);
//        }else{
//            [self setCenter:CGPointMake( (App_Frame_Width / 2), ( barHeight+ACNavBarDrawer_Height / 2.f)-30 )];
//        }
        
        
    }];
}

- (void)closeNavBarDrawer
{
    _isOpen = NO;
    [UIView animateWithDuration:ACNavBarDrawer_Duration animations:^{
        [_mask setAlpha:0.f];
        [self setCenter:CGPointMake( (App_Frame_Width / 2), -( barHeight+ACNavBarDrawer_Height / 2.f) )];
        
        
    } completion:^(BOOL finished) {
        self.hidden=YES;
    }];

}

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 }
 */

@end
