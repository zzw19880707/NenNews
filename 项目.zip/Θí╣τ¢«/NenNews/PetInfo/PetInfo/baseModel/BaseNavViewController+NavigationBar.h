//
//  BaseNavViewController+NavigationBar.h
//  东北新闻网
//
//  Created by tenyea on 13-12-18.
//  Copyright (c) 2013年 佐筱猪. All rights reserved.
//

#import "BaseNavViewController.h"

@interface BaseNavViewController (NavigationBar)
- (void)setBarColor:(UIColor*)color;
@end
