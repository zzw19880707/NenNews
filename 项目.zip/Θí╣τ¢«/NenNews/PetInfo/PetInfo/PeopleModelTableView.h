//
//  PeopleModelTableView.h
//  东北新闻网
//
//  Created by apple on 14-9-4.
//  Copyright (c) 2014年 naxingbo. All rights reserved.
//

#import "BaseTableView.h"

@interface PeopleModelTableView : BaseTableView
{
    UIView *btv;
    UILabel *dLine;
    UIButton *b1;
    UIButton *b2;
}
@end
