//
//  NightModelScrollView.h
//  东北新闻网
//
//  Created by 佐筱猪 on 13-12-23.
//  Copyright (c) 2013年 佐筱猪. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NightModelScrollView : UIScrollView

-(id)init;
@end
