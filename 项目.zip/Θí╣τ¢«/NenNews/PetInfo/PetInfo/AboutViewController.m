//
//  AboutViewController.m
//  东北新闻网
//
//  Created by tenyea on 13-12-23.
//  Copyright (c) 2013年 佐筱猪. All rights reserved.
//

#import "AboutViewController.h"

@interface AboutViewController ()

@end

@implementation AboutViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
//        self.title = @"关    于";
        UILabel *tLabel=[Uifactory createLabel:ttitleText];
        tLabel.frame=CGRectMake(0, 0, 100, 30);
        tLabel.font=[UIFont fontWithName:@"Helvetica-Bold" size:20.0];
        tLabel.textAlignment=UITextAlignmentCenter;
        tLabel.text=@"关于";
        self.navigationItem.titleView=tLabel;

    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    NSString *aboutPath = [[NSBundle mainBundle] pathForResource: @"about" ofType: @"html"];
    NSError *error = nil;
    NSStringEncoding encoding;
    NSString *htmlString = [NSString stringWithContentsOfFile: aboutPath usedEncoding: &encoding error: &error];
//    添加版本号
    NSArray *array = [htmlString componentsSeparatedByString:@"</BODY>"];
    NSString *curversion = [[[NSBundle mainBundle] infoDictionary] objectForKey:(NSString *)kCFBundleVersionKey];
    NSString *centerString = [NSString stringWithFormat:@"<center>Version %@</center>",curversion];
    NSString *newhtmlString = [array componentsJoinedByString:centerString];
    [_webView loadHTMLString: newhtmlString baseURL: nil];
    
}



#pragma mark 内存管理
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_webView release];

    [super dealloc];
}
- (void)viewDidUnload {
    [_webView stopLoading];

    [_webView release];
    _webView = nil;

    [super viewDidUnload];
    

}
@end
