//
//  PeopleViewController.h
//  东北新闻网
//
//  Created by apple on 14-9-3.
//  Copyright (c) 2014年 naxingbo. All rights reserved.
//

#import "BaseViewController.h"
#import "BaseTableView.h"

@class PeopleModelTableView;

@interface PeopleViewController : BaseViewController<UItableviewEventDelegate>

@property (nonatomic,retain) PeopleModelTableView *peopleModelTableView;

@end
