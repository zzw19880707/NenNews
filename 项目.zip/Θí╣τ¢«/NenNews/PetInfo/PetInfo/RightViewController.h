//
//  RightViewController.h
//  东北新闻网
//
//  Created by 佐筱猪 on 13-12-18.
//  Copyright (c) 2013年 佐筱猪. All rights reserved.
//

#import "BaseViewController.h"

@interface RightViewController : BaseViewController <ASIRequest>

- (IBAction)selectAction:(UIButton *)sender;
@end
