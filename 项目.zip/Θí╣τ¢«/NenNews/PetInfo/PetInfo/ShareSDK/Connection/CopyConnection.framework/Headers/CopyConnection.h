//
//  CopyConnection.h
//  CopyConnection
//
//  Created by vimfung on 13-10-27.
//  Copyright (c) 2013年 ShareSDK. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <ShareSDK/ShareSDKPlugin.h>

/**
 *	@brief	拷贝连接器
 */
@interface CopyConnection : NSObject <ISSPlatform>


@end
