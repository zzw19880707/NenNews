//
//  PeopleViewController.m
//  东北新闻网
//
//  Created by apple on 14-9-3.
//  Copyright (c) 2014年 naxingbo. All rights reserved.
//

#import "PeopleViewController.h"
#import "ThemeManager.h"
#import "PeopleModelTableView.h"
#import "NightModelContentViewController.h"
#import "ColumnModel.h"
#import "FMDatabase.h"
#import "FileUrl.h"
@interface PeopleViewController ()

@end

@implementation PeopleViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self showHUD:INFO_RequestNetWork isDim:YES];
    self.view.backgroundColor = [[ThemeManager shareInstance] getBackgroundColor];
    _peopleModelTableView = [[PeopleModelTableView alloc] init];
    _peopleModelTableView.frame = CGRectMake(0, 0, ScreenWidth, ScreenHeight-26);
    _peopleModelTableView.eventDelegate = self;
    [self.view addSubview:_peopleModelTableView];
    NSString *urlstring = @"http://msts.nen.com.cn/MingShengComplain/ComplainServlet?formFlag=getComplainManagerList&queryName=沈阳市&registId=0&spFlag=-2&mainType=1&pageNum=1&pagingNum=10&queryType=mainList&queryMessageType=1";
    urlstring = [urlstring stringByAddingPercentEscapesUsingEncoding:CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingUTF8)];
    urlstring = [urlstring stringByAddingPercentEscapesUsingEncoding:CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingUTF8)];
    ASIHTTPRequest *request=[[ASIHTTPRequest alloc]initWithURL:[NSURL URLWithString:urlstring]];
    [request setTimeOutSeconds:30];
    [request setCompletionBlock:^{
        NSData *data = request.responseData;
        float version = WXHLOSVersion();
        id result = nil ;
        if (version>=5.0) {
            result =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            if ((NSNull *)result == [NSNull null]) {
                [self hideHUD];
                [self showHUD:INFO_ERROR isDim:YES];
                [self performSelector:@selector(hideHUD) withObject:nil afterDelay:1];
                return ;
            }else{//加载正常
                NSArray *newsDataArray = [result objectForKey:@"clist"];
                _peopleModelTableView.data = newsDataArray;
                _peopleModelTableView.lastDate = [NSDate date];
                [_peopleModelTableView reloadData];
                [self performSelector:@selector(hideHUD) withObject:nil afterDelay:.5];
            }
        }
    }];
    [request setFailedBlock:^{
         [self performSelector:@selector(hideHUD) withObject:nil afterDelay:.5];
    }];
    [request startAsynchronous];
}
#pragma mark  UItableviewEventDelegate
//下拉
-(void)pullDown:(BaseTableView *)tableView{
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
  //  [params setValue:self.newsId forKey:@"subjectId"];
    
    
    
    [DataService requestWithURL:URL_getThematic_List andparams:params andhttpMethod:@"GET" completeBlock:^(id result) {
        if ((NSNull *)result == [NSNull null]) {
            [self hideHUD];
            [self showHUD:INFO_ERROR isDim:YES];
            [self performSelector:@selector(hideHUD) withObject:nil afterDelay:1];
            return ;
        }else{//加载正常
            NSArray *newsDataArray = [result objectForKey:@"clist"];
            _peopleModelTableView.data = newsDataArray;
            _peopleModelTableView.lastDate = [NSDate date];
            [_peopleModelTableView reloadData];
            [self performSelector:@selector(hideHUD) withObject:nil afterDelay:.5];
        }
        
    } andErrorBlock:^(NSError *error) {
        [self performSelector:@selector(hideHUD) withObject:nil afterDelay:.5];
    }];
}
-(void)tableView:(PeopleModelTableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
       [tableView deselectRowAtIndexPath:indexPath animated:YES];
}


-(void)	:(ColumnModel *)model {
    NSArray *viewControllers = self.navigationController.viewControllers;
    
    if (viewControllers.count > 2) {
        [self.navigationController popToRootViewControllerAnimated:NO];
    }
    _po(model);
    //插入该cell已经选中
    NSString *newsId = model.newsId;
    NSString *newsAbstract =model.newsAbstract;
    NSString *img = model.img;
    NSString *sql = [NSString stringWithFormat:@"insert into columnData(newsId,title,newsAbstract,type,img,isselected) values('%@','%@','%@',%@,'%@',1) ;",newsId,model.title,newsAbstract,model.type,img];
    _po(sql);
    FMDatabase *db = [FileUrl getDB];
    [db open];
    NightModelContentViewController *nightModel = [[NightModelContentViewController alloc]init];
    
    [db executeUpdate:sql];
    [db close];
    nightModel.newsAbstract = model.newsAbstract;
    nightModel.type = [model.type intValue];
    nightModel.newsId = [NSString stringWithFormat:@"%@",model.newsId];
    nightModel.ImageUrl = model.img;
    nightModel.titleLabel = model.title;
    
    [self.navigationController pushViewController:nightModel animated:YES];
    
}
#pragma mark 内存管理
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
