//
//  VedioAndImageModel.m
//  东北新闻网
//
//  Created by tenyea on 14-2-8.
//  Copyright (c) 2014年 佐筱猪. All rights reserved.
//

#import "VedioAndImageModel.h"

@implementation VedioAndImageModel

@end
