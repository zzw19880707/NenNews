//
//  NewsContentModel.m
//  东北新闻网
//
//  Created by tenyea on 13-12-30.
//  Copyright (c) 2013年 佐筱猪. All rights reserved.
//

#import "NewsContentModel.h"

@implementation NewsContentModel

@end
